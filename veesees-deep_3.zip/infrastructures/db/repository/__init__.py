# -*- coding: utf-8 -*-
# @Author: yaccii
# @Description: Repository package exports.

from .spider_results_repository import SpiderResultsRepository  # noqa: F401
from .voc_repository import VocRepository  # noqa: F401
