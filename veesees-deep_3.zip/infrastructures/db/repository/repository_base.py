# -*- coding: utf-8 -*-
# @Author: yaccii
# @Description:

import time


def now_ts() -> int:
    return int(time.time())
