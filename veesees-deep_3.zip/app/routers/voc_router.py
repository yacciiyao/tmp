# -*- coding: utf-8 -*-
# @Author: yaccii
# @Description: VOC router (placeholder for upcoming modules).

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter(prefix="/voc", tags=["voc"])


@router.get("/ping")
async def ping():
    return {"status": "ok"}
