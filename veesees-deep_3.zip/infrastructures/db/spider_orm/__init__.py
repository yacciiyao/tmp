# -*- coding: utf-8 -*-
# @Author: yaccii
# @Description: Spider (results) DB ORM package. Read-only tables.
