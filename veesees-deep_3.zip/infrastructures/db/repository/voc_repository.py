# -*- coding: utf-8 -*-
# @Author: yaccii
# @Description: VOC repository (service DB).

from __future__ import annotations

from typing import Any, Dict, Optional, List

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from infrastructures.db.orm.voc_orm import MetaVocJobsORM, StgVocOutputsORM
from infrastructures.db.repository.repository_base import now_ts


class VocRepository:
    # -----------------------------
    # Jobs
    # -----------------------------

    @staticmethod
    async def create_job(
        db: AsyncSession,
        *,
        input_hash: str,
        site_code: str,
        scope_type: str,
        scope_value: str,
        params_json: Dict[str, Any],
        status: int = 10,
        stage: Optional[str] = None,
        preferred_task_id: Optional[int] = None,
        preferred_run_id: Optional[int] = None,
    ) -> MetaVocJobsORM:
        job = MetaVocJobsORM(
            input_hash=str(input_hash),
            site_code=str(site_code),
            scope_type=str(scope_type),
            scope_value=str(scope_value),
            params_json=dict(params_json or {}),
            status=int(status),
            stage=stage,
            preferred_task_id=int(preferred_task_id) if preferred_task_id is not None else None,
            preferred_run_id=int(preferred_run_id) if preferred_run_id is not None else None,
        )
        db.add(job)
        await db.flush()
        return job

    @staticmethod
    async def get_job(db: AsyncSession, *, job_id: int) -> Optional[MetaVocJobsORM]:
        stmt = select(MetaVocJobsORM).where(MetaVocJobsORM.job_id == int(job_id))
        res = await db.execute(stmt)
        return res.scalars().first()

    @staticmethod
    async def get_job_by_hash(db: AsyncSession, *, input_hash: str) -> Optional[MetaVocJobsORM]:
        stmt = select(MetaVocJobsORM).where(MetaVocJobsORM.input_hash == str(input_hash))
        res = await db.execute(stmt)
        return res.scalars().first()

    @staticmethod
    async def update_job_status(
        db: AsyncSession,
        *,
        job_id: int,
        status: int,
        stage: Optional[str] = None,
        error_code: Optional[str] = None,
        error_message: Optional[str] = None,
        failed_stage: Optional[str] = None,
    ) -> int:
        values: Dict[str, Any] = {"status": int(status), "updated_at": now_ts()}
        if stage is not None:
            values["stage"] = stage
        if error_code is not None:
            values["error_code"] = error_code
        if error_message is not None:
            values["error_message"] = error_message
        if failed_stage is not None:
            values["failed_stage"] = failed_stage

        stmt = update(MetaVocJobsORM).where(MetaVocJobsORM.job_id == int(job_id)).values(**values)
        res = await db.execute(stmt)
        return int(res.rowcount or 0)

    # -----------------------------
    # Outputs
    # -----------------------------

    @staticmethod
    async def upsert_output(
        db: AsyncSession,
        *,
        job_id: int,
        module_code: str,
        payload_json: Dict[str, Any],
        schema_version: int = 1,
    ) -> StgVocOutputsORM:
        # Fast path: try update first
        stmt = (
            update(StgVocOutputsORM)
            .where(StgVocOutputsORM.job_id == int(job_id), StgVocOutputsORM.module_code == str(module_code))
            .values(payload_json=dict(payload_json or {}), schema_version=int(schema_version), updated_at=now_ts())
        )
        res = await db.execute(stmt)
        if int(res.rowcount or 0) > 0:
            # reload
            got = await VocRepository.get_output(db, job_id=int(job_id), module_code=str(module_code))
            assert got is not None
            return got

        # Insert
        out = StgVocOutputsORM(
            job_id=int(job_id),
            module_code=str(module_code),
            payload_json=dict(payload_json or {}),
            schema_version=int(schema_version),
        )
        db.add(out)
        try:
            await db.flush()
            return out
        except IntegrityError:
            # concurrent insert -> retry as update
            await db.rollback()
            got = await VocRepository.get_output(db, job_id=int(job_id), module_code=str(module_code))
            if got is not None:
                return got
            raise

    @staticmethod
    async def get_output(db: AsyncSession, *, job_id: int, module_code: str) -> Optional[StgVocOutputsORM]:
        stmt = select(StgVocOutputsORM).where(
            StgVocOutputsORM.job_id == int(job_id),
            StgVocOutputsORM.module_code == str(module_code),
        )
        res = await db.execute(stmt)
        return res.scalars().first()

    @staticmethod
    async def list_outputs(db: AsyncSession, *, job_id: int, limit: int = 200, offset: int = 0) -> List[StgVocOutputsORM]:
        stmt = (
            select(StgVocOutputsORM)
            .where(StgVocOutputsORM.job_id == int(job_id))
            .order_by(StgVocOutputsORM.module_code.asc())
            .offset(int(offset))
            .limit(int(limit))
        )
        res = await db.execute(stmt)
        return list(res.scalars().all())
